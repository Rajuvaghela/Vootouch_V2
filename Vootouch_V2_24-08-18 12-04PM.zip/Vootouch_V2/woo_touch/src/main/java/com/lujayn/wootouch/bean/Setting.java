package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 29/03/17.
 */

public class Setting {
    private String min_amount;

    private String requires;

    private String id;

    public String getMin_amount() {
        return min_amount;
    }

    public void setMin_amount(String min_amount) {
        this.min_amount = min_amount;
    }

    public String getRequires() {
        return requires;
    }

    public void setRequires(String requires) {
        this.requires = requires;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 12/10/16.
 */
public class BeanOrderDetail {
    private String count;

    private Data data;

    private String success;

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }
}

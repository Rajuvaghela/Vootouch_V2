package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 20/01/17.
 */

public class Attributes {
    private String attributesName;

    private String attributesID;

    public String getAttributesName() {
        return attributesName;
    }

    public void setAttributesName(String attributesName) {
        this.attributesName = attributesName;
    }

    public String getAttributesID() {
        return attributesID;
    }

    public void setAttributesID(String attributesID) {
        this.attributesID = attributesID;
    }
}

package com.lujayn.wootouch.common;

/**
 * Created by Shailesh on 03/11/17.
 */

public class Config {

    public static final String YOUTUBE_API_KEY = "AIzaSyBIScyDM7AfgHqjNVkEwRqbVNohQFiYHhM";

    // Authorize.netreplace with your CLIENT KEY
    public static final String AUTHORIZE_API_LOGIN_ID = "9Qg5Y6LsfEd"; // replace with your API LOGIN_ID
    public static final String AUTHORIZE_CLIENT_KEY =
            "28NpsPwdeNEUcGzM9L2dm7KCr97aaJ6ZumzD72TaeY8jnY8z47vEQdPh8L3h3vpp";


    /*Stripe config*/
    public static final String STRIPE_KEY = "pk_test_mCHAO4yY5b49HBS3J5VSkKDK";


    /*Paypal config*/
    /*my client id*///public static final String PAYPAL_CLIENT_ID = "AZUt315awpnsV0bOisjII3mDUmSM99IgGCx66Ovx95_Aj3hD7rjwl4m6uv7ICffVHYrOktVdR42jmNQE";
    /*live lujayn *///public static final String PAYPAL_CLIENT_ID = "ATwXoVKg9scg7KMdHWim8r_Jmcsm02C5AndQw0MSv5bqk96r6ybt2W9wcE0jpUNZSSadKWtu-_mY0D1r";
    public static final String PAYPAL_CLIENT_ID = "AdoqOIva4-dRgsLCcBrd03da4INSL74UrQ8KI9baOl-KRiMwyFmyj5C8yan3BpA9iyqNNMwQ7CpE1eLN";
    //public static final String PAYPAL_CLIENT_ID = "AbBhbAKYCTY0pE7Ys3ern9jgk9aq12FshZWH-6RAR8CIiH8gijLLFaQ5kB8y6cr58bT6BXg2biBXwYXN";
    //public static final String PAYPAL_CLIENT_ID = "AYD0LVRP0Ly47WZD3XyOoeRh1b715-z3oWIHgxX3gjfDkwyoHROUvP-ji1QN_YOotekqRRJFS10dKNEI";
}

package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 02/08/16.
 */
public class BeanState {

    private String state_code;
    private String state_name;

    public String getState_code() {
        return state_code;
    }

    public void setState_code(String state_code) {
        this.state_code = state_code;
    }

    public String getState_name() {
        return state_name;
    }

    public void setState_name(String state_name) {
        this.state_name = state_name;
    }
}

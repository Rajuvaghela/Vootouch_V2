package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 24/08/16.
 */
public class Items {

    private String name;

    private String qty;

    private String itemid;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getItemid() {
        return itemid;
    }

    public void setItemid(String itemid) {
        this.itemid = itemid;
    }
}

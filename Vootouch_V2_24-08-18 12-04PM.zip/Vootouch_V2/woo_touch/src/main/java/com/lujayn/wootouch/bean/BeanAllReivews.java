package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 16/09/16.
 */
public class BeanAllReivews {

    private String reviewID;

    private String reviewPostID;

    private String reviewAuthor;

    private String reviewAuthorEmail;

    private String reviewDate;

    private String reviewContent;

    private String reviewUserId;

    private String rating;


    public String getReviewID() {
        return reviewID;
    }

    public void setReviewID(String reviewID) {
        this.reviewID = reviewID;
    }

    public String getReviewPostID() {
        return reviewPostID;
    }

    public void setReviewPostID(String reviewPostID) {
        this.reviewPostID = reviewPostID;
    }

    public String getReviewAuthor() {
        return reviewAuthor;
    }

    public void setReviewAuthor(String reviewAuthor) {
        this.reviewAuthor = reviewAuthor;
    }

    public String getReviewAuthorEmail() {
        return reviewAuthorEmail;
    }

    public void setReviewAuthorEmail(String reviewAuthorEmail) {
        this.reviewAuthorEmail = reviewAuthorEmail;
    }

    public String getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(String reviewDate) {
        this.reviewDate = reviewDate;
    }

    public String getReviewContent() {
        return reviewContent;
    }

    public void setReviewContent(String reviewContent) {
        this.reviewContent = reviewContent;
    }

    public String getReviewUserId() {
        return reviewUserId;
    }

    public void setReviewUserId(String reviewUserId) {
        this.reviewUserId = reviewUserId;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
}

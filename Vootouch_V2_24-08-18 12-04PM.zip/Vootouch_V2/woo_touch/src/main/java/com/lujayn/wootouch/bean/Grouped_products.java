package com.lujayn.wootouch.bean;

import java.util.ArrayList;

/**
 * Created by Shailesh on 13/10/17.
 */

public class Grouped_products {

    private ArrayList<Product> product;

    public ArrayList<Product> getProduct() {
        return product;
    }

    public void setProduct(ArrayList<Product> product) {
        this.product = product;
    }
}

package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 05/08/16.
 */
public class BeanDetailProduct {

    private Data data;

    private String success;


    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }
}

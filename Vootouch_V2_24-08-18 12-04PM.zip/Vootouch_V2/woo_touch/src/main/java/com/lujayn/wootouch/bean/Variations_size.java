package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 05/08/16.
 */
public class Variations_size {

    private String variations_id;

    private String variation_price;

    private String size;

    public String getVariations_id() {
        return variations_id;
    }

    public void setVariations_id(String variations_id) {
        this.variations_id = variations_id;
    }

    public String getVariation_price() {
        return variation_price;
    }

    public void setVariation_price(String variation_price) {
        this.variation_price = variation_price;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }
}

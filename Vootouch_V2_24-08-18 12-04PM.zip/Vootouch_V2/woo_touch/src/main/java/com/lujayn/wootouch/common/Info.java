package com.lujayn.wootouch.common;

/**
 * Created by Shailesh on 21/11/17.
 */

public class Info {

    /*
    language code

    ar = arabic
    da = Danish
    de = German
    es = Spanish
    fr = French
    hi = hindi
    it = italic
    nl = Dutch
    pt = Portuguese
    ru = Russian
    tr = turkic

    */
}

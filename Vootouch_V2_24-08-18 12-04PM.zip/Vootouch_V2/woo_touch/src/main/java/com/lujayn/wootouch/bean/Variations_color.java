package com.lujayn.wootouch.bean;

/**
 * Created by Shailesh on 05/08/16.
 */
public class Variations_color {
    private String color;

    private String variations_id;

    private String variation_price;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getVariations_id() {
        return variations_id;
    }

    public void setVariations_id(String variations_id) {
        this.variations_id = variations_id;
    }

    public String getVariation_price() {
        return variation_price;
    }

    public void setVariation_price(String variation_price) {
        this.variation_price = variation_price;
    }
}

package com.lujayn.wootouch.bean;

import java.util.ArrayList;

/**
 * Created by Shailesh on 02/05/17.
 */

public class Subcategory {

    private ArrayList<BeanProduct> productArrayList;

}
